class History < ActiveRecord::Base
  belongs_to :instance
end
