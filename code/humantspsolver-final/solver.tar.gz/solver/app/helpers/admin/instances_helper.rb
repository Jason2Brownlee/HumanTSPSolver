module Admin::InstancesHelper
end
