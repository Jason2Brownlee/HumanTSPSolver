module Admin::UploadHelper
end
