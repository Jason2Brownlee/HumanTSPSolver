class Coordinate < ActiveRecord::Base
  belongs_to :problem
end
