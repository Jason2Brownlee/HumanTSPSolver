class OptimalTour < ActiveRecord::Base
  belongs_to :problem
end
