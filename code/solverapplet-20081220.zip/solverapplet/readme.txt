copyright, 2008, Jason Brownlee 
HumanTSPSolver.com

