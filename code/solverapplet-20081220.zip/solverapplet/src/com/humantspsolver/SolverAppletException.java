// jason brownlee, 12/05/2008

package com.humantspsolver;

public class SolverAppletException extends RuntimeException
{

	public SolverAppletException()
	{
		// TODO Auto-generated constructor stub
	}

	public SolverAppletException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SolverAppletException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SolverAppletException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
