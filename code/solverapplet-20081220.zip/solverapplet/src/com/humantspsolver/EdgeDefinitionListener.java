// jason brownlee, 10/05/2008

package com.humantspsolver;

public interface EdgeDefinitionListener
{
	/**
	 * Define an edge
	 * @param fromCity
	 * @param toCity
	 */
	void addEdge(Contribution contrib);
}
